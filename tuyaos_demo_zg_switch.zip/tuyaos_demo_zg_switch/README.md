# tuyaos_demo_zg_switch

## 文件列表

### 产品文件列表

| 名称                                        | 说明                                                         |
| ------------------------------------------- | ------------------------------------------------------------ |
| app_config.c<br/>app_config.h               | 功能平台生成的配置文件                                       |
| switch_app_config.h                         | 产品的配置文件，主要用于配置功能是否开启及功能设置           |
| app_common.h                                | 产品的通用处理文件，提供通用的宏定义、函数                   |
| app_dev_register.c<br/>app_dev_register.h   | zigbee的相关文件，用于注册 Endpoint 、Cluster、Attribute 等参数 |
| tuya_sdk_callback.c                         | 产品的主功能文件，初始化、网络状态、命令处理均在此文件实现   |
| app_key.c<br/>app_key.h                     | 按键处理文件，提供长按、短按、触发协议上报、指示灯反馈功能   |
| app_led.c<br/>app_led.h                     | 指示灯处理文件，提供闪灯功能                                 |
| app_onoff_cluster.c<br/>app_onoff_cluster.h | Zigbee Onoff 处理文件，提供下发指令处理、状态上报功能        |

## 文件结构

## 功能描述及配置

这是一款基于 TuyaOS 平台开发的 Zigbee 两路开关 Demo，支持按键、行为指示灯、Zigbee 配网、数据收发处理等功能。

> 说明
>
> 关于 Demo 的详细使用说明，用户可以参考 [两路开关 Demo 开发包](https://developer.tuya.com/cn/docs/iot-device-dev/tuyaos_zigbee_switch_demo_product_development_kit?id=Kdva1hnz8cme5)。

### 基本功能逻辑

| 功能     | 操作                         | 行为                                                         |
| -------- | ---------------------------- | ------------------------------------------------------------ |
| 上电     | 设备重新上电                 | 网络指示灯长亮 3s 后熄灭                                     |
| 配网     | 长按网络按键直至网络灯快闪   | 未配网：网络指示灯灭；<br/>配网中：网络指示灯快闪（ 250ms 间隔）； <br/>配网成功：网络指示灯长亮 3s；<br/>配网超时：网络指示灯熄灭 |
| 按键     | 短按状态按键（按键1、按键2） | 短按后，翻转状态指示灯的开关状态并上报                       |
|          | 长按网络按键                 | 长按 3s 后，进入配网状态，网络指示灯快闪                     |
| 开关状态 | 无需操作                     | 配网成功，15s 后上报开关状态                                 |
|          | 面板控制（开关、开关2）      | 开启开关时，状态指示灯亮并上报开关状态；<br/>关闭开关时，状态指示灯灭并上报开关状态 |

### 配置说明

#### 通用处理文件（app_common.h）

文件功能：**调试串口**使能开关、通用处理的宏/函数等。

- 默认配置如下：

  ```text
  #define USER_PR_ENABLE              1
  
  #ifdef USER_PR_ENABLE
  #ifndef USER_PR_DEBUG
  #define USER_PR_DEBUG(fmt, ...)     TAL_PR_DEBUG_RAW(fmt, ##__VA_ARGS__)
  #endif
  #else
  #ifndef USER_PR_DEBUG
  #define USER_PR_DEBUG(fmt, ...)
  #endif
  #endif
  
  #ifndef GET_ARRAY_LEN
  #define GET_ARRAY_LEN(x)            (SIZEOF(x) / SIZEOF(x[0]))
  #endif
  ```


#### 产品主配置文件（switch_app_config.h）

文件功能：配置按键、指示灯、设备信息等。

- 按键配置：配置按键 I/O 口、有效电平和中断触发模式。

  默认配置如下：
  
  ```text
  //key info
  #define KEY_STA_1_PIN               TUYA_GPIO_NUM_0
  #define KEY_STA_1_ACTIVE_LEVEL      TUYA_GPIO_LEVEL_LOW
  #define KEY_STA_1_IRQ_MODE          TUYA_GPIO_IRQ_RISE_FALL
  
  #define KEY_STA_2_PIN               TUYA_GPIO_NUM_3
  #define KEY_STA_2_ACTIVE_LEVEL      TUYA_GPIO_LEVEL_LOW
  #define KEY_STA_2_IRQ_MODE          TUYA_GPIO_IRQ_RISE_FALL
  
  #define KEY_NWK_PIN                 TUYA_GPIO_NUM_4
  #define KEY_NWK_ACTIVE_LEVEL        TUYA_GPIO_LEVEL_LOW
  #define KEY_NWK_IRQ_MODE            TUYA_GPIO_IRQ_RISE_FALL
  ```
  
  > 不同平台的管脚对应关系不一样。**在使用本产品前，开发者需要根据芯片平台的管脚对应关系修改该配置。**
  >
  > - 对于芯科和泰凌微平台，可在 `tkl_platform_types.h` 文件中查看。
  
- 指示灯配置：可配置指示灯 I/O 口、有效电平和初始化状态。

  默认配置如下：
  
  ```text
  //led info
  #define LED_STA_1_PIN               TUYA_GPIO_NUM_7
  #define LED_STA_1_ACTIVE_LEVEL      TUYA_GPIO_LEVEL_LOW
  #define LED_STA_1_INIT_STATUS       LED_ST_OFF              //OFF
  
  #define LED_STA_2_PIN               TUYA_GPIO_NUM_8
  #define LED_STA_2_ACTIVE_LEVEL      TUYA_GPIO_LEVEL_LOW
  #define LED_STA_2_INIT_STATUS       LED_ST_OFF              //OFF
  
  #define LED_NWK_PIN                 TUYA_GPIO_NUM_19
  #define LED_NWK_ACTIVE_LEVEL        TUYA_GPIO_LEVEL_LOW
  #define LED_NWK_INIT_STATUS         LED_ST_OFF              //OFF
  ```
  
  > **在使用本产品前，开发者需要根据芯片平台的管脚对应关系修改该配置。**
  
- 设备信息配置：配置设备信息、配网超时时长等。

  配置项及功能如下：

  | 配置项                 | 功能                              |
  | ---------------------- | --------------------------------- |
  | ONOFF_1_ENDPOINT       | 开关1默认endpoint序号，不建议修改 |
  | ONOFF_2_ENDPOINT       | 开关2默认endpoint序号，不建议修改 |
  | APP_ZG_NODE_ROUTER     | 设备类型（router），不建议修改    |
  | ZIGBEE_JOIN_TIMEOUT_MS | 配网超时时间，默认30s             |
  | ZCL_ID_ONOFF           | onoff属性值上报时的ZCL ID         |
  | PRESS_JOIN_TIME_MS     | 网络按键长按开启配网时间，默认3s  |

  默认配置如下：

  ```text
  #define PRESS_JOIN_TIME_MS          3000
  
  // device info
  #define ONOFF_1_ENDPOINT            1
  #define ONOFF_2_ENDPOINT            2
  #define APP_ZG_NODE_ROUTER          1
  
  // network info
  #define ZIGBEE_JOIN_TIMEOUT_MS      30000
  
  // data report info
  #define ZCL_ID_ONOFF                100
  ```


#### 基础信息配置

在产品工程文件夹下的 `app_config.yaml`，可配置该产品的 PID、model ID、设备类型等信息。文件支持两种配置方式，**您根据需求任选其一即可**。文件内容及作用如下：

```text
#######################################################################
# COMPATIBILITY of 【Tuya mode】
# For the use of tuya redefined attributes:
# [cluster:0x0000,attribute:0x0004] tuya manu name
# [cluster:0x0000,attribute:0x0005] tuya model id
########################################################################
Firmware_Information:
  description: "this is a demo project"
  device_role: "router"   # router/sleep_end_dev
  image_type: 
  manufacture_id: 
  model_id: "TS0002"
  manufacture_name: "_TZ30001000000_qlizmo9x" # capacity+pid
  module_name: ""
  chip_id: "" # efr32mg21a020f1024im32/efr32mg21a020f768im32/TLSR8258F1KET


########################################################################
# COMPATIBILITY of 【zigbee standard mode】
# For the use of ZCL stardard attributes:
# [cluster:0x0000,attribute:0x0004] ManufacturerName
# [cluster:0x0000,attribute:0x0005] ModelIdentifier
########################################################################
# Firmware_Information:
#   description: "this is a demo project"
#   device_role: "router"   # router/sleep_end_dev
#   image_type: 
#   manufacture_id: 
#   model_id: "custom"
#   manufacture_name: "custom"
#   product_id: "bhzkbugw"
#   capacity: "_TZ30001000000_"
#   product_type: "TS0002"  
#   module_name: ""
#   chip_id: "" # efr32mg21a020f1024im32/efr32mg21a020f768im32/TLSR8258F1KET

```

> 说明
>
> 如果您想要自定义 `model_id` 和 `manufacture_name` 属性，则必须使用第二种配置方式，并填写 `capacity`、`product_type` 和 `product_id` 字段。


| 名称             | 功能                                                         |
| ---------------- | ------------------------------------------------------------ |
| description      | 产品描述字段                                                 |
| device_role      | 设备角色类型，`router`代表正常功耗路由设备，`sleep_end_dev` 代表休眠低功耗设备，请谨慎更改 |
| image_type       | 固件信息，用于 OTA 时验证使用                                |
| manufacture_id   | 厂商 ID，用于 OTA 时验证使用                                 |
| model_id         | 设备型号，用于加入涂鸦网关后确定设备功能，请谨慎更改         |
| manufacture_name | 产品能力值和涂鸦 PID 拼接，用下划线（_）连接，例如 `_TZ30001000000_qlizmo9x` |
| module_name      | 模组型号，指示产品使用的模组                                 |
| chip_id          | 芯片型号，指示产品使用的芯片，请勿更改                       |
| capacity         | 涂鸦产品能力值，该字段请勿更改。如需更改，请咨询涂鸦产品经理 |
| product_type     | 设备型号，用于加入涂鸦网关后确定设备功能，请谨慎更改         |
| product_id       | 涂鸦产品 ID，此处留空，烧录授权时会写入新 PID                |

