/**
 * @file app_key.c
 * @author www.tuya.com
 * @brief app_key module is used to handle key event.
 * @version 0.1
 * @date 2024-07-26
 *
 * @copyright Copyright (c) tuya.inc 2024
 *
 */

#include "tal_sw_timer.h"
#include "tal_gpio.h"
#include "tal_network_mgr.h"

#include "app_key.h"
#include "app_led.h"
#include "app_onoff_cluster.h"

/***********************************************************
************************macro define************************
***********************************************************/
#define PRESS_COUNT_UNIT_MS         10
#define DEBOUNCE_TIME_MS            30
#define LONG_PRESS_TIME_MS          800

/***********************************************************
***********************typedef define***********************
***********************************************************/
typedef enum {
    KEY_ST_RELEASE = 0,
    KEY_ST_PUSH,
}KEY_ST_T;

typedef struct {
    TUYA_GPIO_NUM_E pin_num;                /*key gpio pin num*/
    TUYA_GPIO_LEVEL_E active_level;         /*key gpio pin active level*/
    TUYA_GPIO_IRQ_E irq_mode;               /*key gpio pin irq mode*/

    KEY_ST_T key_status;                    /*key status*/
    TUYA_GPIO_LEVEL_E trigger_level;        /*key irq trigger level*/
    UINT32_T press_time_count;              /*key press time counter*/
}KEY_OPERATOR_T;

/***********************************************************
********************function declaration********************
***********************************************************/
/**
 * @brief __key_irq_cb
 * @note start debounce process
 *
 * @param[in] arg
 * 
 * @return none
 */
STATIC VOID_T __key_irq_cb(VOID_T *arg);

/**
 * @brief __key_debounce_cb
 * @note debounce process and key behavior detection
 *
 * @param[in] timer_id
 * @param[in] arg
 * 
 * @return none
 */
STATIC VOID_T __key_debounce_cb(TIMER_ID timer_id, VOID_T *arg);

/**
 * @brief __key_press_time_count_cb
 * @note when still press, press_time_count++
 *
 * @param[in] timer_id
 * @param[in] arg
 * 
 * @return none
 */
STATIC VOID_T __key_press_time_count_cb(TIMER_ID timer_id, VOID_T *arg);

/**
 * @brief __key_press_deal
 * @note when still press, deal with the key press event
 *
 * @param[in] pin_num
 * 
 * @return none
 */
STATIC VOID_T __key_press_deal(TUYA_GPIO_NUM_E pin_num);

/**
 * @brief __key_release_deal
 * @note when release, deal with the key release event
 *
 * @param[in] pin_num
 * 
 * @return none
 */
STATIC VOID_T __key_release_deal(TUYA_GPIO_NUM_E pin_num);

/***********************************************************
***********************variable define**********************
***********************************************************/
STATIC KEY_OPERATOR_T sg_key_sta_1_op;
STATIC TIMER_ID sg_key_sta_1_debounce_sw;
STATIC TIMER_ID sg_key_sta_1_press_time_count_sw;

STATIC KEY_OPERATOR_T sg_key_sta_2_op;
STATIC TIMER_ID sg_key_sta_2_debounce_sw;
STATIC TIMER_ID sg_key_sta_2_press_time_count_sw;

STATIC KEY_OPERATOR_T sg_key_nwk_op;
STATIC TIMER_ID sg_key_nwk_debounce_sw;
STATIC TIMER_ID sg_key_nwk_press_time_count_sw;

/***********************************************************
***********************function define**********************
***********************************************************/
/**
 * @brief app_led_init
 *
 * @param[in] none
 *
 * @return none
 */
VOID_T app_key_init(VOID_T)
{
    TUYA_GPIO_IRQ_T gpio_irq_cfg = {
        .cb = __key_irq_cb,
    };
    // key_sta_1
    sg_key_sta_1_op.pin_num = KEY_STA_1_PIN;
    sg_key_sta_1_op.active_level = KEY_STA_1_ACTIVE_LEVEL;
    sg_key_sta_1_op.irq_mode = KEY_STA_1_IRQ_MODE;

    gpio_irq_cfg.arg = &sg_key_sta_1_op.pin_num,
    gpio_irq_cfg.mode = KEY_STA_1_IRQ_MODE,
    tal_sw_timer_create(__key_debounce_cb, &sg_key_sta_1_op.pin_num, &sg_key_sta_1_debounce_sw);
    tal_sw_timer_create(__key_press_time_count_cb, &sg_key_sta_1_op.pin_num, &sg_key_sta_1_press_time_count_sw);
    tal_gpio_irq_init(KEY_STA_1_PIN, &gpio_irq_cfg);

    // key_sta_2
    sg_key_sta_2_op.pin_num = KEY_STA_2_PIN;
    sg_key_sta_2_op.active_level = KEY_STA_2_ACTIVE_LEVEL;
    sg_key_sta_2_op.irq_mode = KEY_STA_2_IRQ_MODE;

    gpio_irq_cfg.arg = &sg_key_sta_2_op.pin_num,
    gpio_irq_cfg.mode = KEY_STA_2_IRQ_MODE,
    tal_sw_timer_create(__key_debounce_cb, &sg_key_sta_2_op.pin_num, &sg_key_sta_2_debounce_sw);
    tal_sw_timer_create(__key_press_time_count_cb, &sg_key_sta_2_op.pin_num, &sg_key_sta_2_press_time_count_sw);
    tal_gpio_irq_init(KEY_STA_2_PIN, &gpio_irq_cfg);
    
    // key_sta
    sg_key_nwk_op.pin_num = KEY_NWK_PIN;
    sg_key_nwk_op.active_level = KEY_NWK_ACTIVE_LEVEL;
    sg_key_nwk_op.irq_mode = KEY_NWK_IRQ_MODE;

    gpio_irq_cfg.arg = &sg_key_nwk_op.pin_num,
    gpio_irq_cfg.mode = KEY_NWK_IRQ_MODE,
    tal_sw_timer_create(__key_debounce_cb, &sg_key_nwk_op.pin_num, &sg_key_nwk_debounce_sw);
    tal_sw_timer_create(__key_press_time_count_cb, &sg_key_nwk_op.pin_num, &sg_key_nwk_press_time_count_sw);
    tal_gpio_irq_init(KEY_NWK_PIN, &gpio_irq_cfg);
}

/**
 * @brief __key_irq_cb
 * @note start debounce process
 *
 * @param[in] arg
 * 
 * @return none
 */
STATIC VOID_T __key_irq_cb(VOID_T* arg)
{
    TUYA_GPIO_NUM_E pin_num = *(TUYA_GPIO_NUM_E*)arg;
    if (KEY_STA_1_PIN == pin_num) {
        tal_gpio_read(KEY_STA_1_PIN, &sg_key_sta_1_op.trigger_level);
        tal_sw_timer_start(sg_key_sta_1_debounce_sw, DEBOUNCE_TIME_MS, TAL_TIMER_ONCE);
        return;
    }

    if (KEY_STA_2_PIN == pin_num) {
        tal_gpio_read(KEY_STA_2_PIN, &sg_key_sta_2_op.trigger_level);
        tal_sw_timer_start(sg_key_sta_2_debounce_sw, DEBOUNCE_TIME_MS, TAL_TIMER_ONCE);
        return;
    }

    if (KEY_NWK_PIN == pin_num) {
        tal_gpio_read(KEY_NWK_PIN, &sg_key_nwk_op.trigger_level);
        tal_sw_timer_start(sg_key_nwk_debounce_sw, DEBOUNCE_TIME_MS, TAL_TIMER_ONCE);
        return;
    }
}

/**
 * @brief __key_debounce_cb
 * @note debounce process and key behavior detection
 *
 * @param[in] timer_id
 * @param[in] arg
 * 
 * @return none
 */
STATIC VOID_T __key_debounce_cb(TIMER_ID timer_id, VOID_T* arg)
{
    TUYA_GPIO_NUM_E pin_num = *(TUYA_GPIO_NUM_E*)arg;
    if (KEY_STA_1_PIN == pin_num) {
        TUYA_GPIO_LEVEL_E cur_level;
        tal_gpio_read(KEY_STA_1_PIN, &cur_level);

        if (cur_level != sg_key_sta_1_op.trigger_level) {
            return;
        }

        if (cur_level == sg_key_sta_1_op.active_level) {
            sg_key_sta_1_op.key_status = KEY_ST_PUSH;
            tal_sw_timer_start(sg_key_sta_1_press_time_count_sw, PRESS_COUNT_UNIT_MS, TAL_TIMER_CYCLE);
        } else {
            sg_key_sta_1_op.key_status = KEY_ST_RELEASE;
            tal_sw_timer_stop(sg_key_sta_1_press_time_count_sw);
            __key_release_deal(KEY_STA_1_PIN);
            sg_key_sta_1_op.press_time_count = 0;
        }
        return;
    }

    if (KEY_STA_2_PIN == pin_num) {
        TUYA_GPIO_LEVEL_E cur_level;
        tal_gpio_read(KEY_STA_2_PIN, &cur_level);

        if (cur_level != sg_key_sta_2_op.trigger_level) {
            return;
        }

        if (cur_level == sg_key_sta_2_op.active_level) {
            sg_key_sta_2_op.key_status = KEY_ST_PUSH;
            tal_sw_timer_start(sg_key_sta_2_press_time_count_sw, PRESS_COUNT_UNIT_MS, TAL_TIMER_CYCLE);
        } else {
            sg_key_sta_2_op.key_status = KEY_ST_RELEASE;
            tal_sw_timer_stop(sg_key_sta_2_press_time_count_sw);
            __key_release_deal(KEY_STA_2_PIN);
            sg_key_sta_2_op.press_time_count = 0;
        }
        return;
    }

    if (KEY_NWK_PIN == pin_num) {
        TUYA_GPIO_LEVEL_E cur_level;
        tal_gpio_read(KEY_NWK_PIN, &cur_level);

        if (cur_level != sg_key_nwk_op.trigger_level) {
            return;
        }

        if (cur_level == sg_key_nwk_op.active_level) {
            sg_key_nwk_op.key_status = KEY_ST_PUSH;
            tal_sw_timer_start(sg_key_nwk_press_time_count_sw, PRESS_COUNT_UNIT_MS, TAL_TIMER_CYCLE);
        } else {
            sg_key_nwk_op.key_status = KEY_ST_RELEASE;
            tal_sw_timer_stop(sg_key_nwk_press_time_count_sw);
            __key_release_deal(KEY_NWK_PIN);
            sg_key_nwk_op.press_time_count = 0;
        }
        return;
    }
}

/**
 * @brief __key_press_time_count_cb
 * @note when still press, press_time_count++
 *
 * @param[in] timer_id
 * @param[in] arg
 * 
 * @return none
 */
STATIC VOID_T __key_press_time_count_cb(TIMER_ID timer_id, VOID_T* arg)
{
    TUYA_GPIO_NUM_E pin_num = *(TUYA_GPIO_NUM_E*)arg;
    if (KEY_STA_1_PIN == pin_num) {
        sg_key_sta_1_op.press_time_count++;
        __key_press_deal(KEY_STA_1_PIN);
        return;
    }

    if (KEY_STA_2_PIN == pin_num) {
        sg_key_sta_2_op.press_time_count++;
        __key_press_deal(KEY_STA_2_PIN);
        return;
    }

    if (KEY_NWK_PIN == pin_num) {
        sg_key_nwk_op.press_time_count++;
        __key_press_deal(KEY_NWK_PIN);
        return;
    }
}

/**
 * @brief __key_press_deal
 * @note when still press, deal with the key press event
 *
 * @param[in] pin_num
 * 
 * @return none
 */
STATIC VOID_T __key_press_deal(TUYA_GPIO_NUM_E pin_num)
{
    if (KEY_NWK_PIN == pin_num) {
        if (PRESS_JOIN_TIME_MS == sg_key_nwk_op.press_time_count * PRESS_COUNT_UNIT_MS) {
            tal_zg_join_start(ZIGBEE_JOIN_TIMEOUT_MS);
        }
        return;
    }
}

/**
 * @brief __key_release_deal
 * @note when release, deal with the key release event
 *
 * @param[in] pin_num
 * 
 * @return none
 */
STATIC VOID_T __key_release_deal(TUYA_GPIO_NUM_E pin_num)
{
    LED_ST_E onoff;
    if (KEY_STA_1_PIN == pin_num) {
        if (LONG_PRESS_TIME_MS > sg_key_sta_1_op.press_time_count * PRESS_COUNT_UNIT_MS) {
            app_onoff_cluster_toggle_write_report(ONOFF_1_ENDPOINT, &onoff);
            app_led_set_status(LED_STA_1_PIN, onoff);
        }
        return;
    }

    if (KEY_STA_2_PIN == pin_num) {
        if (LONG_PRESS_TIME_MS > sg_key_sta_2_op.press_time_count * PRESS_COUNT_UNIT_MS) {
            app_onoff_cluster_toggle_write_report(ONOFF_2_ENDPOINT, &onoff);
            app_led_set_status(LED_STA_2_PIN, onoff);
        }
        return;
    }
}
