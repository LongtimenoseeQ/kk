/**
 * @file app_dev_register.c
 * @author www.tuya.com
 * @brief app_dev_register module is used to registst zigbee infomation.
 * @version 0.1
 * @date 2024-07-26
 *
 * @copyright Copyright (c) tuya.inc 2024
 *
 */

#include "tal_endpoint_register.h"
#include "tal_network_mgr.h"

#include "app_dev_register.h"

/***********************************************************
************************macro define************************
***********************************************************/
//attribute list
#define IDENTIFY_ATTR_LIST                                                                                                     \
    {0x0000, ATTR_INT16U_ATTRIBUTE_TYPE, 2, (ATTR_MASK_TOKEN_FAST), 0, {(UINT8_T *)0x0005}},   /* 12 / Identify / identify time*/ \
    {0xFFFD, ATTR_INT16U_ATTRIBUTE_TYPE, 2, (ATTR_MASK_READABLE), 0, {(UINT8_T *)0x0001}},     /* 13 / Identify / cluster revision*/
#define GROUP_ATTR_LIST \
    { 0x0000, ATTR_BITMAP8_ATTRIBUTE_TYPE, 1, (ATTR_MASK_READABLE), 0, (UINT8_T *)0x00 }, /* 12 / Groups / name support*/\
    { 0xFFFD, ATTR_INT16U_ATTRIBUTE_TYPE, 2, (ATTR_MASK_READABLE), 0, (UINT8_T *)0x0002 }, /* 13 / Groups / cluster revision*/
#define SCENE_ATTR_LIST \
    { 0x0000, ATTR_INT8U_ATTRIBUTE_TYPE, 1, (ATTR_MASK_READABLE), 0, (UINT8_T *)0x00 }, /* 15 / Scenes / scene count*/\
    { 0x0001, ATTR_INT8U_ATTRIBUTE_TYPE, 1, (ATTR_MASK_READABLE), 0, (UINT8_T *)0x00 }, /* 16 / Scenes / current scene*/\
    { 0x0002, ATTR_INT16U_ATTRIBUTE_TYPE, 2, (ATTR_MASK_READABLE), 0, (UINT8_T *)0x0000 }, /* 16 / Scenes / current group*/\
    { 0x0003, ATTR_BOOLEAN_ATTRIBUTE_TYPE, 1, (ATTR_MASK_READABLE), 0, (UINT8_T *)0x00 }, /* 17 / Scenes / scene valid*/\
    { 0x0004, ATTR_BITMAP8_ATTRIBUTE_TYPE, 1, (ATTR_MASK_READABLE), 0, (UINT8_T *)0x00 }, /* 18 / Scenes / name support*/\
    { 0xFFFD, ATTR_INT16U_ATTRIBUTE_TYPE, 2, (ATTR_MASK_READABLE), 0, (UINT8_T *)0x0002 }, /* 19 / Scenes / cluster revision*/
#define ONOFF_ATTR_LIST \
    { 0x0000, ATTR_BOOLEAN_ATTRIBUTE_TYPE, 1, (ATTR_MASK_READABLE), 0, { (UINT8_T*)0x00 } }, /* 20 / On/off / OnOff*/\
    { 0xFFFD, ATTR_INT16U_ATTRIBUTE_TYPE, 2, (ATTR_MASK_READABLE), 0, { (UINT8_T*)0x0002 } }, /* 24 / On/off / cluster revision*/

// cluster format
#define DEF_CLUSTER_IDENTIFY_CLUSTER_ID(a) \
    {CLUSTER_IDENTIFY_CLUSTER_ID, (TAL_ATTR_T *)&((a)[0]), GET_ARRAY_LEN((a))},
#define DEF_CLUSTER_GROUPS_CLUSTER_ID(a) \
    {CLUSTER_GROUPS_CLUSTER_ID, (TAL_ATTR_T *)&((a)[0]), GET_ARRAY_LEN((a))},
#define DEF_CLUSTER_SCENES_CLUSTER_ID(a) \
    {CLUSTER_SCENES_CLUSTER_ID, (TAL_ATTR_T *)&((a)[0]), GET_ARRAY_LEN((a))},
#define DEF_CLUSTER_ON_OFF_CLUSTER_ID(a) \
    {CLUSTER_ON_OFF_CLUSTER_ID, (TAL_ATTR_T *)&((a)[0]), GET_ARRAY_LEN((a))},

/***********************************************************
***********************typedef define***********************
***********************************************************/


/***********************************************************
********************function declaration********************
***********************************************************/
/**
 * @brief register router
 *
 * @param[in] none
 *
 * @return none
 */
STATIC VOID_T __router_node_init(VOID_T);

/**
 * @brief register sleep end device
 *
 * @param[in] none
 *
 * @return none
 */
STATIC VOID_T __sleep_end_device_node_init(VOID_T);

/**
 * @brief config join strategy
 *
 * @param[in] none 
 *
 * @return none
 */
STATIC VOID_T __join_network_config(VOID_T);

/***********************************************************
***********************variable define**********************
***********************************************************/
// attribute list
CONST TAL_ATTR_T identify_attr_list[] = {
    IDENTIFY_ATTR_LIST
};
CONST TAL_ATTR_T group_attr_list[] = {
    GROUP_ATTR_LIST
};
CONST TAL_ATTR_T scene_attr_list[] = {
    SCENE_ATTR_LIST
};
CONST TAL_ATTR_T onoff_attr_list[] = {
    ONOFF_ATTR_LIST
};

// server cluster list
CONST TAL_CLUSTER_T onoff_1_ep_server_cluster_list[] = {
    DEF_CLUSTER_IDENTIFY_CLUSTER_ID(identify_attr_list)
    DEF_CLUSTER_GROUPS_CLUSTER_ID(group_attr_list)
    DEF_CLUSTER_SCENES_CLUSTER_ID(scene_attr_list)
    DEF_CLUSTER_ON_OFF_CLUSTER_ID(onoff_attr_list)
};
CONST TAL_CLUSTER_T onoff_2_ep_server_cluster_list[] = {

    DEF_CLUSTER_IDENTIFY_CLUSTER_ID(identify_attr_list)
    DEF_CLUSTER_GROUPS_CLUSTER_ID(group_attr_list)
    DEF_CLUSTER_SCENES_CLUSTER_ID(scene_attr_list)
    DEF_CLUSTER_ON_OFF_CLUSTER_ID(onoff_attr_list)
};

#define ONOFF_1_EP_SERVER_CLUSTER_NUM   GET_ARRAY_LEN(onoff_1_ep_server_cluster_list)
#define ONOFF_2_EP_SERVER_CLUSTER_NUM   GET_ARRAY_LEN(onoff_2_ep_server_cluster_list)

//endpoint descriptor
TAL_ENDPOINT_T dev_endpoint_desc[] = {
    {ONOFF_1_ENDPOINT, ZHA_PROFILE_ID, ZG_DEVICE_ID_ON_OFF_LIGHT_SWITCH, ONOFF_1_EP_SERVER_CLUSTER_NUM, (TAL_CLUSTER_T *)&onoff_1_ep_server_cluster_list[0], 0, NULL},
    {ONOFF_2_ENDPOINT, ZHA_PROFILE_ID, ZG_DEVICE_ID_ON_OFF_LIGHT_SWITCH, ONOFF_2_EP_SERVER_CLUSTER_NUM, (TAL_CLUSTER_T *)&onoff_2_ep_server_cluster_list[0], 0, NULL},
};

/***********************************************************
***********************function define**********************
***********************************************************/
/**
 * @brief register zigbee parameter
 *
 * @param[in] none
 *
 * @return none
 */
VOID_T app_dev_zigbee_init(VOID_T)
{
    //register zigbee endpoint
    tal_zg_endpoint_register(dev_endpoint_desc, GET_ARRAY_LEN(dev_endpoint_desc));

    //zigbee node configuration
#if APP_ZG_NODE_ROUTER
    __router_node_init();
#else
    __sleep_end_device_node_init();
#endif

    //zigbee joining network configuration
    __join_network_config();

    tal_zg_nwk_recovery_disable(TRUE);
}

#if APP_ZG_NODE_ROUTER
/**
 * @brief register router
 *
 * @param[in] none
 *
 * @return none
 */
STATIC VOID_T __router_node_init(VOID_T)
{
    TAL_ZG_NODE_CFG_T node_config = {
        .node_type = ZG_ROUTER,                 //zigbee type, router, end device or sleep end device
        .tx_power = 10,                         //set tx power
        .scan_interval = 0,                     //beacon scan interval
        .scan_duration = ZG_SCAN_DURATION_3,    //beacon scan interval 153.6 ms
    };
    //config zigbee node
    tal_zg_node_config(&node_config);
}
#else
/**
 * @brief register sleep end device
 *
 * @param[in] none
 *
 * @return none
 */
STATIC VOID_T __sleep_end_device_node_init(VOID_T)
{
    TAL_ZG_NODE_CFG_T node_config = {
        .node_type = ZG_SLEEPY_END_DEVICE,
        .tx_power = 10,
        .scan_interval = 300,
        .scan_duration = ZG_SCAN_DURATION_3,
        .config.sleep_ed_cfg.poll_config.forever_flag = 0,
        .config.sleep_ed_cfg.poll_config.fast_swicth_parent = 0,
        .config.sleep_ed_cfg.poll_config.interval_ms = 1000,
        .config.sleep_ed_cfg.poll_config.max_failed_times = 5,
        .config.sleep_ed_cfg.poll_config.duration_after_data_ms = 3000,
        .config.sleep_ed_cfg.poll_config.duration_after_join_ms = 60 * 1000,
        .config.sleep_ed_cfg.poll_config.duration_after_rejoin_ms = 15 * 1000,
        .config.sleep_ed_cfg.rejoin_config.power_on_active = 1,
        .config.sleep_ed_cfg.rejoin_config.send_data_active = 1,
        .config.sleep_ed_cfg.rejoin_config.attempts = 3,
        .config.sleep_ed_cfg.rejoin_config.interval = 1000,
    };
    //config zigbee node
    tal_zg_node_config(&node_config);
}
#endif

/**
 * @brief config join strategy
 *
 * @param[in] none 
 *
 * @return none
 */
STATIC VOID_T __join_network_config(VOID_T)
{
    TAL_ZG_JOIN_CFG_T join_config = {
        .auto_join_power_on_flag = FALSE,           //defalut power on start join or not
        .auto_join_remote_leave_flag = TRUE,        //default start join or not when receivew remote leave request
        .join_timeout = ZIGBEE_JOIN_TIMEOUT_MS,     //join timeout times
    };
    //config join prameter
    tal_zg_join_config(&join_config);
}
