/**
 * @file app_onoff_cluster.h
 * @author www.tuya.com
 * @brief app_onoff_cluster module is used to handle onoff cluster event.
 * @version 0.1
 * @date 2024-07-26
 *
 * @copyright Copyright (c) tuya.inc 2024
 *
 */

#include "tal_attribute_rw.h"
#include "tal_data_send.h"

#include "app_onoff_cluster.h"

/***********************************************************
************************macro define************************
***********************************************************/


/***********************************************************
***********************typedef define***********************
***********************************************************/


/***********************************************************
********************function declaration********************
***********************************************************/
/**
 * @brief report the onoff attribute
 * 
 * @param[in] onoff
 * 
 * @return none 
 */
STATIC VOID_T __report_onoff(UINT8_T ep_id, LED_ST_E onoff);

/***********************************************************
***********************variable define**********************
***********************************************************/


/***********************************************************
***********************function define**********************
***********************************************************/
/**
 * @brief when receive the onoff command, deal with it
 * 
 * @param[in] ep_id
 * @param[in] cmd
 * @param[in] payload
 * @param[in] payload_len
 * @param[in] cmd_type
 * 
 * @return none
 */    
VOID_T app_onoff_cluster_cmd_handler(UINT8_T ep_id, UCHAR_T cmd, UINT8_T *payload, UINT8_T payload_len, ZIGBEE_CMD_E cmd_type)
{
    switch (ep_id) {
        case ONOFF_1_ENDPOINT: {
            switch (cmd) {
                case CMD_OFF_COMMAND_ID: {
                    app_onoff_cluster_write_report(ONOFF_1_ENDPOINT, LED_ST_OFF);
                    app_led_set_status(LED_STA_1_PIN, LED_ST_OFF);
                    break;
                }
                case CMD_ON_COMMAND_ID: {
                    app_onoff_cluster_write_report(ONOFF_1_ENDPOINT, LED_ST_ON);
                    app_led_set_status(LED_STA_1_PIN, LED_ST_ON);
                    break;
                }
                default: {
                    break;
                }
            }
            break;
        }
        case ONOFF_2_ENDPOINT: {
            switch (cmd) {
                case CMD_OFF_COMMAND_ID: {
                    app_onoff_cluster_write_report(ONOFF_2_ENDPOINT, LED_ST_OFF);
                    app_led_set_status(LED_STA_2_PIN, LED_ST_OFF);
                    break;
                }
                case CMD_ON_COMMAND_ID: {
                    app_onoff_cluster_write_report(ONOFF_2_ENDPOINT, LED_ST_ON);
                    app_led_set_status(LED_STA_2_PIN, LED_ST_ON);
                    break;
                }
                default: {
                    break;
                }
            }
            break;
        }
        default: {
            break;
        }
    }
}

/**
 * @brief read, report
 * 
 * @param[in] ep_id
 * 
 * @return none
 */
VOID_T app_onoff_cluster_read_report(UINT8_T ep_id)
{
    LED_ST_E onoff;
    // read
    tal_zg_read_attribute(ep_id, CLUSTER_ON_OFF_CLUSTER_ID, ATTR_ON_OFF_ATTRIBUTE_ID, &onoff, ATTR_BOOLEAN_ATTRIBUTE_TYPE);
    // report
    __report_onoff(ep_id, onoff);
}

/**
 * @brief local write, report
 * 
 * @param[in] ep_id
 * @param[in] onoff
 * 
 * @return none
 */
VOID_T app_onoff_cluster_write_report(UINT8_T ep_id, LED_ST_E onoff)
{
    // update
    tal_zg_write_attribute(ep_id, CLUSTER_ON_OFF_CLUSTER_ID, ATTR_ON_OFF_ATTRIBUTE_ID, &onoff, ATTR_BOOLEAN_ATTRIBUTE_TYPE);
    // report
    __report_onoff(ep_id, onoff);
}

/**
 * @brief toggle, local write, report
 * 
 * @param[in] ep_id
 * @param[out] onoff
 * 
 * @return none
 */
VOID_T app_onoff_cluster_toggle_write_report(UINT8_T ep_id, LED_ST_E *onoff)
{
    LED_ST_E temp_onoff;
    // toggle
    tal_zg_read_attribute(ep_id, CLUSTER_ON_OFF_CLUSTER_ID, ATTR_ON_OFF_ATTRIBUTE_ID, &temp_onoff, ATTR_BOOLEAN_ATTRIBUTE_TYPE);
    if (LED_ST_OFF == temp_onoff) {
        temp_onoff = LED_ST_ON;
    } else {
        temp_onoff = LED_ST_OFF;
    }
    *onoff = temp_onoff;
    // update
    tal_zg_write_attribute(ep_id, CLUSTER_ON_OFF_CLUSTER_ID, ATTR_ON_OFF_ATTRIBUTE_ID, &temp_onoff, ATTR_BOOLEAN_ATTRIBUTE_TYPE);
    // report
    __report_onoff(ep_id, temp_onoff);
}

/**
 * @brief report the onoff attribute
 * 
 * @param[in] onoff
 * 
 * @return none 
 */
STATIC VOID_T __report_onoff(UINT8_T ep_id, LED_ST_E onoff)
{
    TAL_ZG_SEND_DATA_T send_data = {
        .zcl_id = ZCL_ID_ONOFF,
        .delay_time = 0,
        .random_time = 0,
        .qos = QOS_1,
        .direction = ZG_ZCL_DATA_SERVER_TO_CLIENT,
        .frame_type = ZG_ZCL_FRAME_TYPE_GLOBAL,
        .command_id = CMD_REPORT_ATTRIBUTES_COMMAND_ID,

        // unicast to gateway
        .addr.mode = SEND_MODE_DEV,
        .addr.type.dev.dst_addr = TUYA_GATEWAY_ADDRESS,
        .addr.type.dev.dst_ep = 0x01,                           // gateway endpoint
        .addr.type.dev.src_ep = ep_id,                          // device endpoint
        .addr.type.dev.cluster_id = CLUSTER_ON_OFF_CLUSTER_ID,

        .data.zg.attr_sum = 1,
        .data.zg.attr[0].attr_id = ATTR_ON_OFF_ATTRIBUTE_ID,
        .data.zg.attr[0].type = ATTR_BOOLEAN_ATTRIBUTE_TYPE,
        .data.zg.attr[0].size = 1,
        .data.zg.attr[0].value[0] = (UINT8_T)onoff,
    };
    tal_zg_clear_send_data(ZG_CLEAR_ALL_ZCL_ID, &send_data.zcl_id);
    tal_zg_send_data(&send_data, NULL, 1000);
}
