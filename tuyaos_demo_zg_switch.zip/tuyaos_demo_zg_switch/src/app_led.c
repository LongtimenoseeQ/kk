/**
 * @file app_led.c
 * @author www.tuya.com
 * @brief app_led module is used to handle led event.
 * @version 0.1
 * @date 2024-07-26
 *
 * @copyright Copyright (c) tuya.inc 2024
 *
 */

#include "tal_sw_timer.h"
#include "tal_gpio.h"

#include "app_led.h"
#include "app_onoff_cluster.h"

/***********************************************************
************************macro define************************
***********************************************************/
#define BLINK_COUNT_UNIT_MS         10

/***********************************************************
***********************typedef define***********************
***********************************************************/
typedef struct {
    TUYA_GPIO_NUM_E pin_num;                /*led gpio pin num*/
    TUYA_GPIO_LEVEL_E active_level;         /*led gpio pin active level*/

    UINT32_T on_time;                       /*led blink turn on time*/
    UINT32_T off_time;                      /*led blink turn off time*/
    UINT16_T blink_times;                   /*led blink remain times*/
    LED_ST_E end_st;                        /*led blink stop status*/
    UINT32_T count;                         /*led blink time counter*/
}LED_OPERATOR_T;

/***********************************************************
********************function declaration********************
***********************************************************/
/**
 * @brief __led_blink_timer_cb
 * @note blink process
 *
 * @param[in] timer_id: the id of the software timer that triggers the callback
 * @param[in] arg: set in tal_sw_timer_create, used in this callback
 * 
 * @return none
 */
STATIC VOID_T __led_blink_timer_cb(TIMER_ID timer_id, VOID_T *arg);

/***********************************************************
***********************variable define**********************
***********************************************************/
STATIC LED_OPERATOR_T sg_led_sta_1_op;
STATIC TIMER_ID sg_led_sta_1_blink_sw;

STATIC LED_OPERATOR_T sg_led_sta_2_op;
STATIC TIMER_ID sg_led_sta_2_blink_sw;

STATIC LED_OPERATOR_T sg_led_nwk_op;
STATIC TIMER_ID sg_led_nwk_blink_sw;

/***********************************************************
***********************function define**********************
***********************************************************/
/**
 * @brief app_led_init
 *
 * @param[in] none
 *
 * @return none
 */
VOID_T app_led_init(VOID_T)
{
    TUYA_GPIO_BASE_CFG_T gpio_cfg = {
        .mode = TUYA_GPIO_PUSH_PULL,
        .direct = TUYA_GPIO_OUTPUT
    };
    // led_sta_1
    gpio_cfg.level = LED_STA_1_ACTIVE_LEVEL;
    tal_gpio_init(LED_STA_1_PIN, &gpio_cfg);
    app_onoff_cluster_write_report(ONOFF_1_ENDPOINT, LED_STA_1_INIT_STATUS);
    app_led_set_status(LED_STA_1_PIN, LED_STA_1_INIT_STATUS);
    tal_sw_timer_create(__led_blink_timer_cb, &sg_led_sta_1_op, &sg_led_sta_1_blink_sw);

    sg_led_sta_1_op.pin_num = LED_STA_1_PIN;
    sg_led_sta_1_op.active_level = LED_STA_1_ACTIVE_LEVEL;

    // led_sta_2
    gpio_cfg.level = LED_STA_2_ACTIVE_LEVEL;
    tal_gpio_init(LED_STA_2_PIN, &gpio_cfg);
    app_onoff_cluster_write_report(ONOFF_2_ENDPOINT, LED_STA_2_INIT_STATUS);
    app_led_set_status(LED_STA_2_PIN, LED_STA_2_INIT_STATUS);
    tal_sw_timer_create(__led_blink_timer_cb, &sg_led_sta_2_op, &sg_led_sta_2_blink_sw);

    sg_led_sta_2_op.pin_num = LED_STA_2_PIN;
    sg_led_sta_2_op.active_level = LED_STA_2_ACTIVE_LEVEL;

    // led_nwk
    gpio_cfg.level = LED_NWK_ACTIVE_LEVEL;
    tal_gpio_init(LED_NWK_PIN, &gpio_cfg);
    app_led_set_status(LED_NWK_PIN, LED_NWK_INIT_STATUS);
    tal_sw_timer_create(__led_blink_timer_cb, &sg_led_nwk_op, &sg_led_nwk_blink_sw);

    sg_led_nwk_op.pin_num = LED_NWK_PIN;
    sg_led_nwk_op.active_level = LED_NWK_ACTIVE_LEVEL;
}

/**
 * @brief app_led_start_blink
 * @note set the blink config and start the blink process
 *
 * @param[in] pin_num
 * @param[in] on_time
 * @param[in] off_time
 * @param[in] blink_times
 * @param[in] end_st
 *
 * @return none
 */
VOID_T app_led_start_blink(TUYA_GPIO_NUM_E pin_num, UINT32_T on_time, UINT32_T off_time, UINT32_T blink_times, LED_ST_E end_st)
{
    if (LED_STA_1_PIN == pin_num) {
        sg_led_sta_1_op.on_time = on_time;
        sg_led_sta_1_op.off_time = off_time;
        sg_led_sta_1_op.blink_times = blink_times;
        sg_led_sta_1_op.end_st = end_st;
        sg_led_sta_1_op.count = 0;
        tal_sw_timer_start(sg_led_sta_1_blink_sw, BLINK_COUNT_UNIT_MS, TAL_TIMER_CYCLE);
        return;
    }

    if (LED_STA_2_PIN == pin_num) {
        sg_led_sta_2_op.on_time = on_time;
        sg_led_sta_2_op.off_time = off_time;
        sg_led_sta_2_op.blink_times = blink_times;
        sg_led_sta_2_op.end_st = end_st;
        sg_led_sta_2_op.count = 0;
        tal_sw_timer_start(sg_led_sta_2_blink_sw, BLINK_COUNT_UNIT_MS, TAL_TIMER_CYCLE);
        return;
    }

    if (LED_NWK_PIN == pin_num) {
        sg_led_nwk_op.on_time = on_time;
        sg_led_nwk_op.off_time = off_time;
        sg_led_nwk_op.blink_times = blink_times;
        sg_led_nwk_op.end_st = end_st;
        sg_led_nwk_op.count = 0;
        tal_sw_timer_start(sg_led_nwk_blink_sw, BLINK_COUNT_UNIT_MS, TAL_TIMER_CYCLE);
        return;
    }
}

/**
 * @brief app_led_set_status
 * @note set led status, LED_ST_ON / LED_ST_OFF
 *
 * @param[in] pin_num
 * @param[in] led_status
 *
 * @return none
 */
VOID_T app_led_set_status(TUYA_GPIO_NUM_E pin_num, LED_ST_E led_status)
{
    if (LED_STA_1_PIN == pin_num) {
        if (LED_ST_OFF == led_status) {         // off
            if (TUYA_GPIO_LEVEL_LOW == LED_STA_1_ACTIVE_LEVEL) {
                tal_gpio_write(LED_STA_1_PIN, TUYA_GPIO_LEVEL_HIGH);
            } else {
                tal_gpio_write(LED_STA_1_PIN, TUYA_GPIO_LEVEL_LOW);
            }
        } else {                                // on
            if (TUYA_GPIO_LEVEL_LOW == LED_STA_1_ACTIVE_LEVEL) {
                tal_gpio_write(LED_STA_1_PIN, TUYA_GPIO_LEVEL_LOW);
            } else {
                tal_gpio_write(LED_STA_1_PIN, TUYA_GPIO_LEVEL_HIGH);
            }
        }
        return;
    }

    if (LED_STA_2_PIN == pin_num) {
        if (LED_ST_OFF == led_status) {         // off
            if (TUYA_GPIO_LEVEL_LOW == LED_STA_2_ACTIVE_LEVEL) {
                tal_gpio_write(LED_STA_2_PIN, TUYA_GPIO_LEVEL_HIGH);
            } else {
                tal_gpio_write(LED_STA_2_PIN, TUYA_GPIO_LEVEL_LOW);
            }
        } else {                                // on
            if (TUYA_GPIO_LEVEL_LOW == LED_STA_2_ACTIVE_LEVEL) {
                tal_gpio_write(LED_STA_2_PIN, TUYA_GPIO_LEVEL_LOW);
            } else {
                tal_gpio_write(LED_STA_2_PIN, TUYA_GPIO_LEVEL_HIGH);
            }
        }
        return;
    }

    if (LED_NWK_PIN == pin_num) {
        if (LED_ST_OFF == led_status) {         // off
            if (TUYA_GPIO_LEVEL_LOW == LED_NWK_ACTIVE_LEVEL) {
                tal_gpio_write(LED_NWK_PIN, TUYA_GPIO_LEVEL_HIGH);
            } else {
                tal_gpio_write(LED_NWK_PIN, TUYA_GPIO_LEVEL_LOW);
            }
        } else {                                // on
            if (TUYA_GPIO_LEVEL_LOW == LED_NWK_ACTIVE_LEVEL) {
                tal_gpio_write(LED_NWK_PIN, TUYA_GPIO_LEVEL_LOW);
            } else {
                tal_gpio_write(LED_NWK_PIN, TUYA_GPIO_LEVEL_HIGH);
            }
        }
        return;
    }
}

/**
 * @brief __led_blink_timer_cb
 * @note blink process
 *
 * @param[in] timer_id: the id of the software timer that triggers the callback
 * @param[in] arg: set in tal_sw_timer_create, used in this callback
 * 
 * @return none
 */
STATIC VOID_T __led_blink_timer_cb(TIMER_ID timer_id, VOID_T *arg)
{
    LED_OPERATOR_T *led_op = (LED_OPERATOR_T *)arg;

    if (led_op->count >= (led_op->on_time + led_op->off_time) / BLINK_COUNT_UNIT_MS) {
        led_op->count = 0;
        led_op->blink_times--;
        if (0 == led_op->blink_times) {
            led_op->on_time = 0;
            led_op->off_time = 0;
            led_op->blink_times = 0;
            led_op->count = 0;

            app_led_set_status(led_op->pin_num, led_op->end_st);
            if (LED_STA_1_PIN == led_op->pin_num) {
                tal_sw_timer_stop(sg_led_sta_1_blink_sw);
                return;
            }
            if (LED_STA_2_PIN == led_op->pin_num) {
                tal_sw_timer_stop(sg_led_sta_2_blink_sw);
                return;
            }
            if (LED_NWK_PIN == led_op->pin_num) {
                tal_sw_timer_stop(sg_led_nwk_blink_sw);
                return;
            }
        }
    }

    if (led_op->count < led_op->on_time / BLINK_COUNT_UNIT_MS) {
        app_led_set_status(led_op->pin_num, LED_ST_ON);
    } else {
        app_led_set_status(led_op->pin_num, LED_ST_OFF);
    }

    led_op->count++;
}
