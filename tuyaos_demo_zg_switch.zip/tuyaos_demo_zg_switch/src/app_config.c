/*************************************************************************************/
/* Automatically-generated file. Do not edit! */
/*************************************************************************************/

#include "app_config.h"
#include "tuya_iot_config.h"
#include "tal_firmware_cfg.h"


OPERATE_RET tuya_app_firmware_config(VOID_T)
{
    TAL_FW_INIT_T fw_init = {
        .name = BUILD_FIRMNAME,
        .model_id = APP_MODEL_ID,
        .manu_name = APP_MANUFACTURE_NAME,
        .capacity = APP_CAPACITY,
        .product_id = APP_PRODUCR_ID,
        .product_type = APP_PRODUCT_TYPE,
        .fw_version = FW_VERSION_HEX,
        .manu_id = APP_MANUFACTURE_ID,
        .image_type = APP_IMAGE_TYPE,
    };
    return tal_firmware_info_init(&fw_init);
}


OPERATE_RET tuya_sdk_information_config(VOID_T)
{
    CHAR_T *sdk_ver = IOT_SDK_VER;
    CHAR_T *kcfg_ver = "0.0.0";
    CHAR_T *kernel_ver = KERNEL_VERSION;
    return tal_tuyaos_info_init(sdk_ver, kcfg_ver, kernel_ver);
}


