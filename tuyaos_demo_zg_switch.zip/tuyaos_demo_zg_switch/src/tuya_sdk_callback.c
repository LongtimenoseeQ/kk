/**
 * @file tuya_sdk_callback.c
 * @author www.tuya.com
 * @brief tuya_sdk_callback module is used to handle common function.
 * @version 0.1
 * @date 2024-07-26
 *
 * @copyright Copyright (c) tuya.inc 2024
 *
 */

#include "tkl_memory.h"
#include "tal_memory.h"
#include "tal_sw_timer.h"
#include "tal_zcl_scene.h"
#include "tal_network_mgr.h"
#include "tal_data_receive.h"
#include "tal_reset_factory.h"
#include "tal_heartbeat.h"
#include "tal_mf_test.h"
#include "tal_attribute_rw.h"

#include "switch_app_config.h"
#include "app_common.h"
#include "app_dev_register.h"
#include "app_onoff_cluster.h"
#include "app_key.h"
#include "app_led.h"

/***********************************************************
************************macro define************************
***********************************************************/


/***********************************************************
***********************typedef define***********************
***********************************************************/


/***********************************************************
********************function declaration********************
***********************************************************/
STATIC VOID_T app_network_up_delay_event_handler(TIMER_ID timer_id, VOID_T *arg);
//app event create
STATIC VOID_T app_event_init(VOID_T);
//debug uart init
STATIC VOID_T app_debug_uart_init(VOID_T);
//debug output create
STATIC VOID_T app_uart_output(IN CONST  CHAR_T *str);
//app oem init
STATIC VOID_T app_oem_init(VOID_T);

/***********************************************************
***********************variable define**********************
***********************************************************/
//app event and handler
TIMER_ID etimer_network_up_delay_event_id;

/***********************************************************
***********************function define**********************
***********************************************************/

/**
 * @brief app network up delay event create
 * 
 * @param[in] none
 * 
 * @return: none
 */
STATIC VOID_T app_event_init(VOID_T)
{
    tal_sw_timer_create(app_network_up_delay_event_handler, NULL, &etimer_network_up_delay_event_id);
}

/**
 * @brief network up delay event
 * 
 * @param[in] timer_id: timer id
 * @param[in] args: null
 * 
 * @return: none
 */
STATIC VOID_T app_network_up_delay_event_handler(TIMER_ID timer_id, VOID_T *arg)
{
    app_onoff_cluster_read_report(ONOFF_1_ENDPOINT);
    app_onoff_cluster_read_report(ONOFF_2_ENDPOINT);
}

/**
 * @brief oem init
 * 
 * @param[in] none
 * 
 * @return: none
 */
STATIC VOID_T app_oem_init(VOID_T)
{
    app_key_init();
    app_led_init();
}


/**
 * @brief Generally used for peripheral initialization
 * @note In this function, you can init uart and log here
 *
 * @param[in] none
 *
 * @return OPERATE_RET
 */
OPERATE_RET tuya_init_first(VOID_T)
{
    app_debug_uart_init();
    tal_mf_test_disable_beacon_test();
    USER_PR_DEBUG("/*********first init*********/\r\n");
    return OPRT_OK;
}

/**
 * @brief Generally used for register zigbee device
 * @note In this function, you can register endpoint, config node and config join strategy here 
 *
 * @param[in] none
 *
 * @return OPERATE_RET
 */
OPERATE_RET tuya_init_second(VOID_T)
{
    app_dev_zigbee_init();

    USER_PR_DEBUG("/*********1.0.0 second init*********/\r\n");
    return OPRT_OK;
}

/**
 * @brief Generally used for initialization before manufacturing test
 * @note includes: beacon mf test, PCBA mf test, RF dongle mf test, double dongle mf test.
 *       In mf test, the TUYA_UART_NUM_0 (used as debug uart in this demo) will be reinit.
 *       In this function, you can make some initialization to prepare for the mf test.
 * 
 * @param[in] none
 *
 * @return OPERATE_RET
 */
OPERATE_RET tuya_init_third(VOID_T)
{
    USER_PR_DEBUG("/*********third init*********/\r\n");
    return OPRT_OK;
}

/**
 * @brief Generally used for initialization after manufacturing test
 * @note After mf test, the TUYA_UART_NUM_0 should be init again if you want to use it.
 *       In this function, you can init peripherals and set events.
 *
 * @param[in] none
 *
 * @return OPERATE_RET
 */
OPERATE_RET tuya_init_last(VOID_T)
{
    app_debug_uart_init();
    app_oem_init();

    app_event_init();

    app_led_start_blink(LED_NWK_PIN, 3000, 200, 1, LED_ST_OFF);

    USER_PR_DEBUG("/*********last init*********/\r\n");
    return OPRT_OK;
}

/**
 * @brief user-defined callback interface in main loop.
 * @note do not block
 *
 * @param[in] none
 *
 * @return OPERATE_RET
 */
OPERATE_RET tuya_main_loop(VOID_T)
{
    return OPRT_OK;
}

/**
 * @brief general message receive callback
 * 
 * @param[in] msg : the pointer of receiving message.
 * 
 * @return TAL_MSG_RET_E 
 */
TAL_MSG_RET_E tal_zcl_general_msg_recv_callback(TAL_ZCL_MSG_T *msg)
{
    //USER_PR_DEBUG("app gen msg cb: cluster 0x%02x, cmd %d\r\n", msg->cluster, msg->command);

    return ZCL_MSG_RET_SUCCESS;
}

/**
 * @brief post-write attribute callback
 *
 * @param[in] ep_id:      endpoint id
 * @param[in] cluster_id: cluster id
 * @param[in] attr_rec:   point to attribute record 
 * 
 * @return write status
 */
TAL_WRITE_RET_E tal_zg_post_write_attribute_callback(UINT8_T ep_id, 
                                                                UINT16_T cluster_id,
                                                                TAL_ATTR_REC_T *attr_rec)
{
    if (ONOFF_1_ENDPOINT == ep_id) {
        switch (cluster_id) {
            case CLUSTER_ON_OFF_CLUSTER_ID: {
                if (ATTR_ON_OFF_ATTRIBUTE_ID == attr_rec->attr_id) {
                }
                break;
            }
            default: {
                break;
            }
        }
    }
    if (ONOFF_2_ENDPOINT == ep_id) {
        switch (cluster_id) {
            case CLUSTER_ON_OFF_CLUSTER_ID: {
                if (ATTR_ON_OFF_ATTRIBUTE_ID == attr_rec->attr_id) {
                }
                break;
            }
            default: {
                break;
            }
        }
    }
    return WRITE_RET_SUCCESS;
}

/**
 * @brief specific message receive callback
 * 
 * @param[in] msg 
 * 
 * @return TAL_MSG_RET_E 
 */
TAL_MSG_RET_E tal_zcl_specific_msg_recv_callback(TAL_ZCL_MSG_T *msg)
{
    USER_PR_DEBUG("app spec msg cb: cluster 0x%02x, cmd 0x%02x\r\n", msg->cluster, msg->command);

    ZIGBEE_CMD_E app_cmd_type = ZIGBEE_CMD_SINGLE;
    if (msg->mode == ZG_UNICAST_MODE)
    {
        app_cmd_type = ZIGBEE_CMD_SINGLE;
        USER_PR_DEBUG("receive single message\r\n");
    }
    else
    {
        app_cmd_type = ZIGBEE_CMD_GROUP;
        USER_PR_DEBUG("receive group message\r\n");
    }
    USER_PR_DEBUG("app command type %d\r\n", app_cmd_type);


    switch (msg->cluster)
    {
        case CLUSTER_ON_OFF_CLUSTER_ID: {
            app_onoff_cluster_cmd_handler(msg->dst_ep, msg->command, msg->payload, msg->length, app_cmd_type);
            break;
        }
        default: {
            break;
        }
    }

    return ZCL_MSG_RET_SUCCESS;
}

/**
 * @brief pre-save scene callback
 * 
 * @param[in] ep_id 
 * @param[in] scene_id 
 * @param[in] group_id 
 * 
 * @return VOID_T 
 */
VOID_T tal_zg_scene_pre_save_callback(UINT8_T ep_id, UINT8_T scene_id, UINT16_T group_id)
{
    //USER_PR_DEBUG("scene pre save: ep %d, sce %d, gp 0x%02x\r\n", ep_id, scene_id, group_id);
}

/**
 * @brief save scene callback(add scene and store scene)
 * 
 * @param[in] ep_id 
 * @param[in] scene_id 
 * @param[in] group_id 
 * @param[in] data 
 * 
 * @return VOID_T 
 */
VOID_T tal_zg_scene_save_callback(UINT8_T ep_id, UINT8_T scene_id, UINT16_T group_id, TAL_SCENE_DATA_T *data)
{
    //USER_PR_DEBUG("scene save: ep %d, sce %d, gp 0x%02x, type %d\r\n", ep_id, scene_id, group_id, data->type);

   //TODO
}
/**
 * @brief recall scene callback
 *
 * @param[in]   ep_id:     endpoint id
 * @param[in]   scene_id:  scene id
 * @param[in]   group_id:  group id
 * @param[in]   time100ms: scene transition time(bat:100ms)
 * @param[in]   data:      point to scene data
 * 
 * @return  VOID_T
 */
VOID_T tal_zg_scene_recall_callback(UINT8_T ep_id, UINT8_T scene_id, UINT16_T group_id, UINT_T time100ms, TAL_SCENE_DATA_T *data)
{
    //USER_PR_DEBUG("scene recall: ep %d, sce %d, gp 0x%02x, type %d\r\n", ep_id, scene_id, group_id, data->type);

    //TODO
}

/**
 * @brief add group callback
 *
 * @param[in]   ep_id:    endpoint id
 * @param[in]   group_id: group id
 * 
 * @return  VOID_T
 */
VOID_T tal_zg_add_group_callback(UINT8_T ep_id, UINT16_T group_id)
{
    USER_PR_DEBUG("ep_id=%d, group_id=0x%04x", ep_id, group_id);
}

/**
 * @brief view group callback
 *
 * @param[in]   ep_id:    endpoint id
 * @param[in]   group_id: group id
 * 
 * @return  VOID_T
 */
VOID_T tal_zg_view_group_callback(UINT8_T ep_id, UINT16_T group_id)
{
    USER_PR_DEBUG("ep_id=%d, group_id=0x%04x", ep_id, group_id);
}

/**
 * @brief remove group callback
 *
 * @param[in]   ep_id:    endpoint id
 * @param[in]   group_id: group id
 * 
 * @return  VOID_T
 */
VOID_T tal_zg_remove_group_callback(UINT8_T ep_id, UINT16_T group_id)
{
    USER_PR_DEBUG("ep_id=%d, group_id=0x%04x", ep_id, group_id);
}

/**
 * @brief zigbee network network change callback(user can rewrite this API)
 * 
 * @param[in]   status: network status
 * 
 * @return VOID_T
 */
VOID_T tal_zg_nwk_status_changed_callback(TAL_ZG_NWK_STATUS_E status)
{
    STATIC BOOL_T power_on_rejoin = TRUE;

    switch (status)
    {
        case TAL_ZG_NWK_POWER_ON_LEAVE:
        {
            USER_PR_DEBUG("power_on_leave---\r\n");
            break;
        }
        case TAL_ZG_NWK_POWER_ON_ONLINE:
        {
            USER_PR_DEBUG("power_on_online---\r\n");
            break;
        }
        case TAL_ZG_NWK_JOIN_START:         // led_nwk blink 
        {
            USER_PR_DEBUG("nwk_join_start---\r\n");
            app_led_start_blink(LED_NWK_PIN, 250, 250, ZIGBEE_JOIN_TIMEOUT_MS / 500, LED_ST_OFF);
            break;
        }
        case TAL_ZG_NWK_JOIN_OK:            // led_nwk on for 3s, update_report after 15s
        {
            USER_PR_DEBUG("nwk_join_ok---\r\n");
            app_led_start_blink(LED_NWK_PIN, 3000, 200, 1, LED_ST_OFF);
            tal_sw_timer_start(etimer_network_up_delay_event_id, 15000, TAL_TIMER_ONCE);
            break;
        }
        case TAL_ZG_NWK_REJOIN_OK:          // update_report after 15s
        {
            //Rejoin should report, but don't need restart sensor.
            tal_sw_timer_start(etimer_network_up_delay_event_id, 15000, TAL_TIMER_ONCE);

            USER_PR_DEBUG("nwk_rejoin_ok---\r\n");
            if (power_on_rejoin == FALSE) {
                //Normal rejoin, sleep dev don't need care.
                break;
            }

            power_on_rejoin = FALSE;
            break;
        }
        case TAL_ZG_NWK_JOIN_TIMEOUT:
        {
            USER_PR_DEBUG("nwk_join_timeout---\r\n");
            break;
        }
        case TAL_ZG_NWK_LOST:
        {
            USER_PR_DEBUG("nwk_lost---\r\n");
            break;
        }
        case TAL_ZG_NWK_REMOTE_LEAVE:       // join start
        {
            USER_PR_DEBUG("nwk_remote_leave---\r\n");
            tal_zg_join_start(ZIGBEE_JOIN_TIMEOUT_MS);
            USER_PR_DEBUG("zigbee join start %d.\r\n", ZIGBEE_JOIN_TIMEOUT_MS);

            break;
        }
        case TAL_ZG_NWK_LOCAL_LEAVE:
        {
            USER_PR_DEBUG("nwk_local_leave---\r\n");

            break;
        }
        case TAL_ZG_NWK_MF_TEST_LEAVE:
        {
            USER_PR_DEBUG("nwk_mf_test_leave---\r\n");
            break;
        }
        default:
        {
            break;
        }
    }
}
/**
 * @brief reset factory default callback
 *
 * @param[in]   type: reset factory type
 * 
 * @return  VOID_T
 */
VOID_T tal_zg_reset_factory_default_callback(TAL_RESET_TYPE_T type)
{
    USER_PR_DEBUG("receive reset to factory default cmd %d\r\n", type);
}

BOOL_T tal_abnormal_wakeup_callback(VOID_T)
{
    return FALSE;
}

/**
 * @note uart init
 * 
 * @param[in] none 
 * 
 * @return: OPERATE_RET
 */
STATIC VOID_T app_debug_uart_init(VOID_T)
{
#ifndef MCU_CORE_8258
    TAL_UART_CFG_T cfg;
    tal_system_memset(&cfg, 0, SIZEOF(TAL_UART_CFG_T));

    cfg.rx_buffer_size = 128;
    cfg.open_mode = 0;
    cfg.base_cfg.baudrate = 115200;
    cfg.base_cfg.parity = TUYA_UART_PARITY_TYPE_NONE;
    cfg.base_cfg.databits = TUYA_UART_DATA_LEN_8BIT;
    cfg.base_cfg.stopbits =TUYA_UART_STOP_LEN_1BIT;
    cfg.base_cfg.flowctrl = TUYA_UART_FLOWCTRL_NONE;
    tal_uart_init(TUYA_UART_NUM_0, &cfg);

    tal_log_create_manage_and_init(TAL_LOG_LEVEL_DEBUG, 128, app_uart_output);  // set log print function
#else
    /**
     * for all platforms.
     *     1. How to disable log print?
     *         set the value of 'USER_PR_ENABLE' to '0'. (file: 'app_common.h')
     * 
     * for 'MCU_CORE_8258'.
     *     it uses 'visual uart' rather than 'TUYA_UART_NUM_0' to print log.
     *     1. How to open 'visual uart'?
     *         opened default.
     *         
     *     2. How to change 'visual uart' gpio?
     *         change the config in 'app_print_get_cfg()'.
     *         this function will be called automatically, you don't need to call it again.
     * 
     *     3. How to use 'TUYA_UART_NUM_0' but not 'visual uart' to print log?
     *         change the macro situation in 'app_debug_uart_init()'
     */
    extern int Tl_printf(const char *format, ...);
    tal_log_create_manage_and_init(TAL_LOG_LEVEL_DEBUG, 128, Tl_printf);        // set log print function
#endif
}

/**
 * @brief configuration of the debug uart.
 * 
 * @param[in] str 
 * 
 * @return VOID_T 
 */
STATIC VOID_T app_uart_output(IN CONST  CHAR_T *str)
{
    UINT8_T * v_buff=(UINT8_T *)tal_malloc(tal_system_strlen(str)+1);
    if(v_buff==NULL)
    {
        return;
    }
    tal_system_memcpy(v_buff,str,tal_system_strlen(str)+1);
    tal_uart_write(TUYA_UART_NUM_0, v_buff,tal_system_strlen((CHAR_T *)v_buff));
    tal_free(v_buff);
    v_buff=NULL;
}

// The phy solution chips need to adjust heap size. others forget it.
#ifdef PHY622X_EVB

#define APP_HEAP_SIZE 6*1024
STATIC uint8_t gs_heap[APP_HEAP_SIZE];
VOID_T tkl_memory_cfg(UINT8_T **out_buff, UINT32_T *out_buff_len)
{
    *out_buff = gs_heap;
    *out_buff_len = APP_HEAP_SIZE;
}

#endif

#ifdef MCU_CORE_8258
#include "tkl_platform_types.h"

BOOL_T app_print_get_cfg(UINT8_T *print_type, UINT8_T *disable_irq, GPIO_PORT_PIN_T *gpio)
{
    // set uart tx gpio
    gpio->port = PORT_C;
    gpio->pin = PIN_4;
    *print_type = 0;
    *disable_irq = 1;
#ifdef UART_PRINTF_MODE
    return 1;
#else
    return 0;
#endif
}

BOOL_T tkl_gpio_output_use_wakeup_mode(TUYA_GPIO_NUM_E pin_id)
{
    return FALSE;
}

#endif
