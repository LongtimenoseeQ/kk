/**
 * @file app_led.h
 * @author www.tuya.com
 * @brief app_led module is used to provide app led function.
 * @version 0.1
 * @date 2024-07-26
 *
 * @copyright Copyright (c) tuya.inc 2024
 *
 */

#ifndef __APP_LED_H__
#define __APP_LED_H__

#include "switch_app_config.h"
#include "app_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/***********************************************************
************************macro define************************
***********************************************************/


/***********************************************************
***********************typedef define***********************
***********************************************************/
typedef enum {
    LED_ST_OFF = 0,
    LED_ST_ON,
}LED_ST_E;

/***********************************************************
********************function declaration********************
***********************************************************/
/**
 * @brief app_led_init
 *
 * @param[in] none
 *
 * @return none
 */
VOID_T app_led_init(VOID_T);

/**
 * @brief app_led_start_blink
 * @note set the blink config and start the blink process
 *
 * @param[in] pin_num
 * @param[in] on_time
 * @param[in] off_time
 * @param[in] blink_times
 * @param[in] end_st
 *
 * @return none
 */
VOID_T app_led_start_blink(TUYA_GPIO_NUM_E pin_num, UINT32_T on_time, UINT32_T off_time, UINT32_T blink_times, LED_ST_E end_st);

/**
 * @brief app_led_set_status
 * @note set led status, LED_ST_ON / LED_ST_OFF
 *
 * @param[in] pin_num
 * @param[in] led_status
 *
 * @return none
 */
VOID_T app_led_set_status(TUYA_GPIO_NUM_E pin_num, LED_ST_E led_status);

#ifdef __cplusplus
}
#endif

#endif /* __APP_LED_H__ */
