/**
 * @file app_dev_register.h
 * @author www.tuya.com
 * @brief app_dev_register module is used to registst zigbee infomation.
 * @version 0.1
 * @date 2024-07-26
 *
 * @copyright Copyright (c) tuya.inc 2024
 *
 */

#ifndef __APP_DEV_REGISTER_H__
#define __APP_DEV_REGISTER_H__

#include "switch_app_config.h"
#include "app_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/***********************************************************
************************macro define************************
***********************************************************/


/***********************************************************
***********************typedef define***********************
***********************************************************/


/***********************************************************
********************function declaration********************
***********************************************************/

/**
 * @brief register zigbee parameter
 *
 * @param[in] none
 *
 * @return none
 */
VOID_T app_dev_zigbee_init(VOID_T);


#ifdef __cplusplus
}
#endif

#endif /* __APP_DEV_REGISTER_H__ */
