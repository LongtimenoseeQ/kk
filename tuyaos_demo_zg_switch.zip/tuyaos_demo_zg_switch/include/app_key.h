/**
 * @file app_key.h
 * @author www.tuya.com
 * @brief app_key module is used to provide app key function.
 * @version 0.1
 * @date 2024-07-26
 *
 * @copyright Copyright (c) tuya.inc 2024
 *
 */

#ifndef __APP_KEY_H__
#define __APP_KEY_H__

#include "switch_app_config.h"
#include "app_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/***********************************************************
************************macro define************************
***********************************************************/


/***********************************************************
***********************typedef define***********************
***********************************************************/


/***********************************************************
********************function declaration********************
***********************************************************/
/**
 * @brief app_led_init
 *
 * @param[in] none
 *
 * @return none
 */
VOID_T app_key_init(VOID_T);

#ifdef __cplusplus
}
#endif

#endif /* __APP_KEY_H__ */
