/**
 * @file app_onoff_cluster.h
 * @author www.tuya.com
 * @brief app_onoff_cluster module is used to handle onoff cluster event.
 * @version 0.1
 * @date 2024-07-26
 *
 * @copyright Copyright (c) tuya.inc 2024
 *
 */

#ifndef __APP_ONOFF_CLUSTER_H__
#define __APP_ONOFF_CLUSTER_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include "switch_app_config.h"
#include "app_common.h"

#include "app_led.h"

/***********************************************************
************************macro define************************
***********************************************************/


/***********************************************************
***********************typedef define***********************
***********************************************************/


/***********************************************************
********************function declaration********************
***********************************************************/
/**
 * @brief when receive the onoff command, deal with it
 * 
 * @param[in] ep_id
 * @param[in] cmd
 * @param[in] payload
 * @param[in] payload_len
 * @param[in] cmd_type
 * 
 * @return none
 */
VOID_T app_onoff_cluster_cmd_handler(UINT8_T ep_id, UCHAR_T cmd, UINT8_T *payload, UINT8_T payload_len, ZIGBEE_CMD_E cmd_type);

/**
 * @brief read, report
 * 
 * @param[in] ep_id
 * 
 * @return none
 */
VOID_T app_onoff_cluster_read_report(UINT8_T ep_id);

/**
 * @brief local write, report
 * 
 * @param[in] ep_id
 * @param[in] onoff
 * 
 * @return none
 */
VOID_T app_onoff_cluster_write_report(UINT8_T ep_id, LED_ST_E onoff);

/**
 * @brief toggle, local write, report
 * 
 * @param[in] ep_id
 * @param[out] onoff
 * 
 * @return none
 */
VOID_T app_onoff_cluster_toggle_write_report(UINT8_T ep_id, LED_ST_E *onoff);

#ifdef __cplusplus
}
#endif

#endif /* __APP_ONOFF_CLUSTER_H__ */
