/**
 * @file app_common.h
 * @author www.tuya.com
 * @brief app_common module is used to provide app common macro and function.
 * @version 0.1
 * @date 2024-07-26
 *
 * @copyright Copyright (c) tuya.inc 2024
 *
 */

#ifndef __APP_COMMON_H__
#define __APP_COMMON_H__

#include "tuya_cloud_types.h"
#include "tal_log.h"

#ifdef __cplusplus
extern "C" {
#endif

/***********************************************************
************************macro define************************
***********************************************************/
#define USER_PR_ENABLE              1

#ifdef USER_PR_ENABLE
#ifndef USER_PR_DEBUG
#define USER_PR_DEBUG(fmt, ...)     TAL_PR_DEBUG_RAW(fmt, ##__VA_ARGS__)
#endif
#else
#ifndef USER_PR_DEBUG
#define USER_PR_DEBUG(fmt, ...)
#endif
#endif

#ifndef GET_ARRAY_LEN
#define GET_ARRAY_LEN(x)            (SIZEOF(x) / SIZEOF(x[0]))
#endif

/***********************************************************
***********************typedef define***********************
***********************************************************/


/***********************************************************
********************function declaration********************
***********************************************************/

#ifdef __cplusplus
}
#endif

#endif /* __APP_COMMON_H__ */
