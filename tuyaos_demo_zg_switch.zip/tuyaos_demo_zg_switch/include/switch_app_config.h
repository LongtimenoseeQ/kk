/**
 * @file switch_app_config.h
 * @author www.tuya.com
 * @brief switch_app_config module is used to config switch category feature.
 * @version 0.1
 * @date 2024-07-26
 *
 * @copyright Copyright (c) tuya.inc 2024
 *
 */

#ifndef __SWITCH_APP_CONFIG_H__
#define __SWITCH_APP_CONFIG_H__

#include "tkl_platform_types.h"

#ifdef __cplusplus
extern "C" {
#endif

/***********************************************************
************************macro define************************
***********************************************************/
//key info
#define KEY_STA_1_PIN               TUYA_GPIO_NUM_0
#define KEY_STA_1_ACTIVE_LEVEL      TUYA_GPIO_LEVEL_LOW
#define KEY_STA_1_IRQ_MODE          TUYA_GPIO_IRQ_RISE_FALL

#define KEY_STA_2_PIN               TUYA_GPIO_NUM_3
#define KEY_STA_2_ACTIVE_LEVEL      TUYA_GPIO_LEVEL_LOW
#define KEY_STA_2_IRQ_MODE          TUYA_GPIO_IRQ_RISE_FALL

#define KEY_NWK_PIN                 TUYA_GPIO_NUM_4
#define KEY_NWK_ACTIVE_LEVEL        TUYA_GPIO_LEVEL_LOW
#define KEY_NWK_IRQ_MODE            TUYA_GPIO_IRQ_RISE_FALL

//led info
#define LED_STA_1_PIN               TUYA_GPIO_NUM_7
#define LED_STA_1_ACTIVE_LEVEL      TUYA_GPIO_LEVEL_LOW
#define LED_STA_1_INIT_STATUS       LED_ST_OFF              //OFF

#define LED_STA_2_PIN               TUYA_GPIO_NUM_8
#define LED_STA_2_ACTIVE_LEVEL      TUYA_GPIO_LEVEL_LOW
#define LED_STA_2_INIT_STATUS       LED_ST_OFF              //OFF

#define LED_NWK_PIN                 TUYA_GPIO_NUM_19
#define LED_NWK_ACTIVE_LEVEL        TUYA_GPIO_LEVEL_LOW
#define LED_NWK_INIT_STATUS         LED_ST_OFF              //OFF

#define PRESS_JOIN_TIME_MS          3000

// device info
#define ONOFF_1_ENDPOINT            1
#define ONOFF_2_ENDPOINT            2
#define APP_ZG_NODE_ROUTER          1

// network info
#define ZIGBEE_JOIN_TIMEOUT_MS      30000

// data report info
#define ZCL_ID_ONOFF                100

/***********************************************************
***********************typedef define***********************
***********************************************************/
typedef enum {
  ZIGBEE_CMD_SINGLE = 0,
  ZIGBEE_CMD_GROUP
} ZIGBEE_CMD_E;

/***********************************************************
********************function declaration********************
***********************************************************/

#ifdef __cplusplus
}
#endif

#endif /* __SWITCH_APP_CONFIG_H__ */
